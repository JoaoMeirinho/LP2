﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pcalc
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void txtNum2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txtNum2.Text, out numero2))
            {
                errorProvider2.SetError(txtNum2, "Número 2 inválido");
                txtNum2.Focus();
            }
            else
                errorProvider2.SetError(txtNum2, "");
        }

        private void btnSoma_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txtResultado.Text = resultado.ToString("F2");
        }

        private void btnSubtracao_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txtResultado.Text = resultado.ToString("F2");
        }

        private void btnMultiplicacao_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txtResultado.Text = resultado.ToString("F2");
        }

        private void btnDivisao_Click(object sender, EventArgs e)
        {
            try
            {
                if (numero2 == 0) throw new DivideByZeroException();
                resultado = numero1 / numero2;
                txtResultado.Text = resultado.ToString("F2");
            }catch(DivideByZeroException)
            {
                MessageBox.Show("Divisor deve ser diferente de 0");
                txtNum2.Focus();
            }
           
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if(MessageBox.Show("Você deseja sair?","Saída", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == DialogResult.Yes)
            {
                Close();
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtNum1.Text = String.Empty;
            txtNum2.Text      = String.Empty;
            txtResultado.Text = String.Empty;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtNum1_Validated(object sender, EventArgs e)
        {
            if(!Double.TryParse(txtNum1.Text, out numero1))
            {
                errorProvider1.SetError(txtNum1, "Número 1 inválido");
                txtNum1.Focus();
            }
            else
                errorProvider1.SetError(txtNum1, "");


        }
    }
}
