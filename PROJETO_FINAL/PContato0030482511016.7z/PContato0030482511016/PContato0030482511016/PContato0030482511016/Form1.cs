﻿using System;
using System.Windows.Forms;
using System.Data.Sql;
using System.Data.SqlClient;
using System.Linq;


namespace PContato0030482511016
{
    public partial class frmPrincipal : Form
    {
        public static SqlConnection conn;
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                conn = new SqlConnection("Data Source=APOLO;Initial Catalog=BD;Persist Security Info=True;User ID=BD2511016;Password=Mafe@thais@roberto123");
                conn.Open();

            } 
            catch (SqlException ex)
            {
                MessageBox.Show("Erro de banco de dados =/" + ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show("Outros erro =/" + ex.Message);
            }

        }

        private void cadastroDeContatosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmContato>().Count() > 0)
            {
                Application.OpenForms["FrmContato"].BringToFront();
            }
            else
            {
                FrmContato objC = new FrmContato();
                objC.MdiParent = this;
                objC.WindowState = FormWindowState.Maximized;
                objC.Show();
            }
        }

        private void sobreToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms.OfType<FrmSobre>().Count() > 0)
            {
                Application.OpenForms["FrmSobre"].BringToFront();
            }
            else
            {
                FrmSobre objC = new FrmSobre();
                objC.MdiParent = this;
                objC.WindowState = FormWindowState.Maximized;
                objC.Show();
            }
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Close();
        }
    }
}
