﻿using Microsoft.VisualBasic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Pvendas02
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            double[,] vendasMesSemana = new double[2, 4];
            double totalGeral = 0;

            for (int i = 0; i < vendasMesSemana.GetLength(0); i++)
            {
                double totalMes = 0;
                for (int j = 0; j < vendasMesSemana.GetLength(1); j++)
                {
                    
                    if(!double.TryParse(Interaction.InputBox($"Digite a venda do mês {i + 1} na semana {j + 1}", "Respostas"), out vendasMesSemana[i, j])){
                        MessageBox.Show("Digite apenas valores numéricos!");
                        j--;
                        continue;
                    }
                    if (vendasMesSemana[i,j] < 0)
                    {
                        MessageBox.Show("Os valores deve ser maiores que 0!");
                        vendasMesSemana[i,j] = 0;
                        j--;
                        continue;
                    }
                    lbVendas.Items.Add($"Total do mês {i + 1} Semana {j + 1}: {vendasMesSemana[i,j]:N2}");
                    totalMes += vendasMesSemana[i, j];
                   
                }
                lbVendas.Items.Add($">> Total mês {i + 1}: {totalMes:N2}");
                totalGeral += totalMes;

                lbVendas.Items.Add("-----------------------------");
            }
            lbVendas.Items.Add($"Total Geral: {totalGeral:N2}");


        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            lbVendas.Items.Clear();
        }
    }
}
